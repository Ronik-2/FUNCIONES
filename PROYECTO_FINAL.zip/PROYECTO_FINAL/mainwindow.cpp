#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include "paginaprincipal.h"
#include <QPixmap>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    connect(ui->btnEntrar,&QPushButton::clicked,this,&MainWindow::validarLogin);
    QPixmap logoFarma(":/imag/logoFarmacia.jpg");
    ui->logo->setPixmap(logoFarma);
    ui->logo->setScaledContents(true);
    QPixmap logoLogin(":/imag/login.jpg");
    ui->Login->setPixmap(logoLogin);
    ui->Login->setScaledContents(true);
}
void MainWindow::validarLogin()
{
    QString usuario = ui->txtUSER->text();
    QString clave = ui->txtClave->text();
    if (usuario.isEmpty() || clave.isEmpty()){
        QMessageBox::warning(this,"Error","Campos vacios");
        return;
    }
    if (usuario=="admin" && clave=="12345"){
        QMessageBox::information(this,"INICIO DE SESION EXITOSO","Credenciales correctas\nBienvenido a PHARMACY");
        paginaPrincipal* ventana2 = new paginaPrincipal();
        ventana2->show();
        this->hide();

    }
    else {
        QMessageBox::critical(this,"Error","Usuario o Clave incorrecto");
    }


}
MainWindow::~MainWindow()
{
    delete ui;
}
