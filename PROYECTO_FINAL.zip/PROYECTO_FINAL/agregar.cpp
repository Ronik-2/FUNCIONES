#include "agregar.h"
#include "ui_agregar.h"
#include <QMessageBox>
#include <QDate>
agregar::agregar(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::agregar)
{
    ui->setupUi(this);
    connect(ui->btnGuardar,&QPushButton::clicked,this,&agregar::guardar);
    connect(ui->btnRegresar,&QPushButton::clicked,this,&agregar::mensaje);
}


void agregar::guardar(){

    QString articulo= ui->txtArticulo->text();
    QString cantidad=ui->txtCantidad->text();
    QString fecha=ui->txtFecha->text();
    QDate fechaValida = QDate::fromString(fecha,"dd/MM/yyyy");
    QString comentario=ui->txtComentario->toPlainText();
    if (articulo.isEmpty() || cantidad.isEmpty() || fecha.isEmpty()){
        QMessageBox::warning(this,"Error","Todos los campos son obligatorios");
        return;
    }
    if(!fechaValida.isValid()){
        QMessageBox::warning(this,"Error","El formato no es valido (dd/MM/yyyy)");
        return;
    }
    emit datos(articulo,cantidad,fecha,comentario);
}
void agregar::setDatosExistentes(const QString &articulo,const QString &cantidad,const QString &fecha,const QString &comentario){
    ui->txtArticulo->setText(articulo);
    ui->txtCantidad->setText(cantidad);
    ui->txtFecha->setText(fecha);
    ui->txtComentario->setText(comentario);
};
void agregar::mensaje(){
    QMessageBox::warning(this,"Salida forzosa","No se guardo el elemento");
    close();
}
agregar::~agregar()
{
    delete ui;
}
