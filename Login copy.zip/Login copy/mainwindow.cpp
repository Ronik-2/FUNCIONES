#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include "paginaprincipal.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    connect(ui->btnEntrar,&QPushButton::clicked,this,&MainWindow::validarLogin);
}
void MainWindow::validarLogin()
{
    QString usuario = ui->txtUSER->text();
    QString clave = ui->txtClave->text();
    if (usuario.isEmpty() || clave.isEmpty()){
        QMessageBox::warning(this,"Error","Campos vacios");
        return;
    }
    if (usuario=="admin" && clave=="12345"){
        QMessageBox::information(this,"Correco","Credenciales correctas");
        paginaPrincipal* ventana2 = new paginaPrincipal();
        ventana2->show();
        this->hide();

    }
    else {
        QMessageBox::critical(this,"Error","Usuario o Clave incorrecto");
    }


}
MainWindow::~MainWindow()
{
    delete ui;
}
