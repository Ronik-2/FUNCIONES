#ifndef PAGINAPRINCIPAL_H
#define PAGINAPRINCIPAL_H
#include <QVector>
#include <QString>
#include <QWidget>
class agregar;
struct itemInventario{
    QString articulo;
    QString cantidad;
    QString fecha;
    QString comentario;
};
namespace Ui {
class paginaPrincipal;
}

class paginaPrincipal : public QWidget
{
    Q_OBJECT

public:
    explicit paginaPrincipal(QWidget *parent = nullptr);
    ~paginaPrincipal();

private:
    Ui::paginaPrincipal *ui;
    QVector<itemInventario>inventario;
    void guardarArchivo();
    void cargarDatos();
    void mostrarEnLista();
    int filaSeleccionada=-1;
    agregar *ventanaEditar=nullptr;
    agregar *ventanaAgregar=nullptr;
private slots:
    void abrirAgregar();
    void recibirDatos(QString articulo,QString cantidad,QString fecha , QString comentario);
    void on_table_itemSelectionChanged();
    void on_btnEliminar_clicked();
    void filtrarTabla(const QString &texto);
    void abrirEditar();
    void recibirDatosEditados(QString articulo,QString cantidad,QString fecha , QString comentario);
    void abrirMostrar();
};


#endif // PAGINAPRINCIPAL_H
