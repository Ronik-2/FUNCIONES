#ifndef AGREGAR_H
#define AGREGAR_H

#include <QWidget>

namespace Ui {
class agregar;
}

class agregar : public QWidget
{
    Q_OBJECT

public:
    explicit agregar(QWidget *parent = nullptr);
    ~agregar();
    void setDatosExistentes(const QString &articulo,const QString &cantidad,const QString &fecha,const QString &comentario);

signals:
    void datos(QString articulo,QString Cantidad,QString fecha,QString Comentario);
private:
    Ui::agregar *ui;
    void mensaje();
private slots:
    void guardar();
};


#endif // AGREGAR_H  ]
