#include "ventanamostrar.h"
#include "ui_ventanamostrar.h"

ventanaMostrar::ventanaMostrar(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::ventanaMostrar)
{
    ui->setupUi(this);
    connect(ui->btnRegresar,&QPushButton::clicked,this,&QWidget::close);
}
void ventanaMostrar::cargarArticulo(QString articulo,QString cantidad,QString fecha,QString comentario){
    ui->txtArticulo->setText(articulo);
    ui->txtCantidad->setText(cantidad);
    ui->txtFecha->setText(fecha);
    ui->txtComentario->setText(comentario);

}
ventanaMostrar::~ventanaMostrar()
{
    delete ui;
}
