#ifndef VENTANAMOSTRAR_H
#define VENTANAMOSTRAR_H

#include <QWidget>

namespace Ui {
class ventanaMostrar;
}

class ventanaMostrar : public QWidget
{
    Q_OBJECT

public:
    explicit ventanaMostrar(QWidget *parent = nullptr);
    ~ventanaMostrar();
public slots:
    void cargarArticulo(QString articulo,QString cantidad,QString fecha,QString comentario);

private:
    Ui::ventanaMostrar *ui;

};

#endif // VENTANAMOSTRAR_H
