#include "ventanaeliminar.h"
#include "ui_ventanaeliminar.h"

ventanaEliminar::ventanaEliminar(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::ventanaEliminar)
{
    ui->setupUi(this);
}

ventanaEliminar::~ventanaEliminar()
{
    delete ui;
}
