#ifndef VENTANAELIMINAR_H
#define VENTANAELIMINAR_H

#include <QWidget>

namespace Ui {
class ventanaEliminar;
}

class ventanaEliminar : public QWidget
{
    Q_OBJECT

public:
    explicit ventanaEliminar(QWidget *parent = nullptr);
    ~ventanaEliminar();

private:
    Ui::ventanaEliminar *ui;
};

#endif // VENTANAELIMINAR_H
