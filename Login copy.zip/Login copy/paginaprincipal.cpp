#include "paginaprincipal.h"
#include "ui_paginaprincipal.h"
#include "agregar.h"
#include <QFile>
#include <QTextStream>
#include <QMessageBox>
#include "ventanamostrar.h"
paginaPrincipal::paginaPrincipal(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::paginaPrincipal)
{
    ui->setupUi(this);
    ui->table->setColumnCount(4);
    QStringList headers;
    headers<<"Medicamento"<<"Cantidad"<<"Fecha de entrega"<<"Comentarios";
    ui->table->setHorizontalHeaderLabels(headers);
    cargarDatos();
    mostrarEnLista();
    connect(ui->btnAgregar,&QPushButton::clicked,this,&paginaPrincipal::abrirAgregar);
    connect(ui->txtBuscar,&QLineEdit::textChanged,this,&paginaPrincipal::filtrarTabla);
    connect(ui->btnEditar,&QPushButton::clicked,this,&paginaPrincipal::abrirEditar);
    connect(ui->btnMostrar,&QPushButton::clicked,this,&paginaPrincipal::abrirMostrar);
;}
void paginaPrincipal::abrirAgregar(){
    ventanaAgregar=new agregar (this);
    connect(ventanaAgregar,&agregar::datos,this,&paginaPrincipal::recibirDatos);
    ventanaAgregar->show();
}
void paginaPrincipal::recibirDatos(QString articulo,QString cantidad,QString fecha , QString comentario){
    for (const itemInventario& d:inventario){
        if (d.articulo.compare(articulo,Qt::CaseInsensitive)==0){
            QMessageBox::warning(this,"Archivo duplicado","El elemento ya existe\nEditelo o eliminelo");return;
        }
    }
    itemInventario n;
    n.articulo=articulo;
    n.cantidad=cantidad;
    n.comentario=comentario;
    n.fecha=fecha;
    inventario.append(n);
    guardarArchivo();
    mostrarEnLista();
    if (ventanaAgregar){
        ventanaAgregar->close();
        ventanaAgregar=nullptr;
    }
}
void paginaPrincipal::cargarDatos(){
    QFile archivo ("farmacia.txt");
    if (!archivo.exists()) return;
    if (!archivo.open(QIODevice::ReadOnly | QIODevice::Text))return;
    QTextStream in (&archivo);
    inventario.clear();
    while (!in.atEnd()) {
        QString linea=in.readLine();
        QStringList partes=linea.split(";");
        if (partes.size()<4) continue;
        itemInventario R;
        R.articulo=partes[0];
        R.cantidad=partes[1];
        R.fecha=partes[2];
        R.comentario=partes[3];
        inventario.append(R);
    }
    archivo.close();
}
void paginaPrincipal::mostrarEnLista(){
    ui->table->setRowCount(0);
    for (const itemInventario& a:inventario){
        int fila=ui->table->rowCount();
        ui->table->insertRow(fila);
        ui->table->setItem(fila,0,new QTableWidgetItem(a.articulo));
        ui->table->setItem(fila,1,new QTableWidgetItem(a.cantidad));
        ui->table->setItem(fila,2,new QTableWidgetItem(a.fecha));
        ui->table->setItem(fila,3,new QTableWidgetItem(a.comentario));
    }
    ui->table->clearSelection();

}
void paginaPrincipal::guardarArchivo(){

    QFile archivo("farmacia.txt");
    if (!archivo.open(QIODevice::WriteOnly | QIODevice::Text)){
        return;
    }
    QTextStream out (&archivo);
    for (const itemInventario& a:inventario){
        out<<a.articulo<<";"
            <<a.cantidad<<";"
            <<a.fecha<<";"
            <<a.comentario<<"\n";
    }
    archivo.close();
}
void paginaPrincipal::on_table_itemSelectionChanged(){
    filaSeleccionada=ui->table->currentRow();
}
void paginaPrincipal::on_btnEliminar_clicked(){
    int fila=ui->table->currentRow();
    if (fila<0 || fila>=inventario.size()){
        QMessageBox::warning(this,"Eliminar","Seleccione un elemento primero");
        return;
    }
    int r=QMessageBox::question(this,"Confirmar","Seguro q quieres eliminar?",
    QMessageBox::Yes | QMessageBox::No);
    if (r==QMessageBox::No)return;
    inventario.removeAt(fila);
    guardarArchivo();
    mostrarEnLista();
}
void paginaPrincipal::filtrarTabla(const QString &texto){
    QString filtro=texto.toLower();
    for (int fila=0;fila<ui->table->rowCount();fila++)
    {
        bool coincide =false;
        for (int col=0;col<ui->table->columnCount();col++){
            QTableWidgetItem *item=ui->table->item(fila,col);
            if (item && item->text().toLower().contains(filtro)){
                coincide=true;
                break;
            }
        }ui->table->setRowHidden(fila,!coincide);
    }
}
void paginaPrincipal::recibirDatosEditados(QString articulo,QString cantidad,QString fecha , QString comentario){
    for (int i=0;i<inventario.size();i++){
        if (i==filaSeleccionada){
            continue;
        }
        if (inventario[i].articulo.compare(articulo,Qt::CaseInsensitive)==0){
            QMessageBox::warning(this,"Elemento duplicado","Ingrese un nombre diferente");
            return;
        }

    }
    inventario[filaSeleccionada].articulo=articulo;
    inventario[filaSeleccionada].cantidad=cantidad;
    inventario[filaSeleccionada].fecha=fecha;
    inventario[filaSeleccionada].comentario=comentario;
    guardarArchivo();
    mostrarEnLista();
    if (ventanaEditar){
        ventanaEditar->close();
        ventanaEditar=nullptr;
    }

}
void paginaPrincipal::abrirMostrar(){
    if (filaSeleccionada<0 || filaSeleccionada>inventario.size()){
        QMessageBox::warning(this,"Valor incorrectc","Seleccione un elemento ");
        return;
    }
    ventanaMostrar *v=new ventanaMostrar(this);
    v->cargarArticulo(inventario[filaSeleccionada].articulo,inventario[filaSeleccionada].cantidad,
inventario[filaSeleccionada].fecha,inventario[filaSeleccionada].comentario);
    v->show();

}
void paginaPrincipal::abrirEditar(){
    if (filaSeleccionada<0 || filaSeleccionada>=inventario.size()){
        QMessageBox::warning(this,"Eliminar","Seleccione un elemento primero");
        return;
    }
    ventanaEditar= new agregar(this);
    ventanaEditar->setDatosExistentes(inventario[filaSeleccionada].articulo,inventario[filaSeleccionada].cantidad,inventario[filaSeleccionada].fecha,inventario[filaSeleccionada].comentario);
    connect(ventanaEditar,&agregar::datos,this,&paginaPrincipal::recibirDatosEditados);
    ventanaEditar->show();
}

paginaPrincipal::~paginaPrincipal()
{
    delete ui;
}
